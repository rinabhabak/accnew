<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_Storelocator
 */


namespace Amasty\Storelocator\Model\Import\Proxy\Location;

class ResourceModel extends \Amasty\Storelocator\Model\ResourceModel\Location
{
}
