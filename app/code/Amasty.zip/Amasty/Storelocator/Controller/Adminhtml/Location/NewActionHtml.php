<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_Storelocator
 */


namespace Amasty\Storelocator\Controller\Adminhtml\Location;

class NewActionHtml extends \Magento\SalesRule\Controller\Adminhtml\Promo\Quote\NewActionHtml
{
    /**
     * New action html action
     *
     * @return void
     */
    public function execute()
    {
        parent::execute();
    }
}
