<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_Feed
 */


namespace Amasty\Feed\Setup;

use Magento\Catalog\Model\Product\Attribute\Repository;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup;

class UpgradeData implements UpgradeDataInterface
{
    protected $executor;

    protected $updater;
    /**
     * @var Repository
     */
    private $attributeRepository;
    /**
     * @var \Amasty\Base\Setup\SerializedFieldDataConverter
     */
    private $fieldDataConverter;
    /**
     * @var \Magento\Framework\App\ProductMetadataInterface
     */
    private $productMetaData;

    /**
     * @var \Magento\Framework\App\State
     */
    private $appState;

    public function __construct(
        Setup\SampleData\Executor $executor,
        Updater $updater,
        Repository $attributeRepository,
        \Magento\Framework\App\ProductMetadataInterface $productMetaData,
        \Amasty\Base\Setup\SerializedFieldDataConverter $fieldDataConverter,
        \Magento\Framework\App\State $appState
    ) {
        $this->executor = $executor;
        $this->updater = $updater;
        $this->attributeRepository = $attributeRepository;
        $this->fieldDataConverter = $fieldDataConverter;
        $this->productMetaData = $productMetaData;
        $this->appState = $appState;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $this->appState->emulateAreaCode(
            \Magento\Backend\App\Area\FrontNameResolver::AREA_CODE,
            [$this, 'upgradeDataWithEmulationAreaCode'],
            [$setup, $context]
        );
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgradeDataWithEmulationAreaCode(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        if (!$context->getVersion()) {
            return;
        }

        $setup->startSetup();
        if (version_compare($context->getVersion(), '1.0.1') < 0) {
            $this->updater->setTemplates(['bing']);
            $this->executor->exec($this->updater);
        } else if (version_compare($context->getVersion(), '1.1.4') < 0) {
            $attributesForConditions = ['status', 'quantity_and_stock_status'];
            foreach ($attributesForConditions as $code) {
                $attribute = $this->attributeRepository->get($code);
                $attribute->setIsUsedForPromoRules(true);
                $this->attributeRepository->save($attribute);
            }
        }

        if (version_compare($context->getVersion(), '1.3.5', '<')
            && $this->productMetaData->getVersion() >= "2.2.0"
        ) {
            $this->fieldDataConverter->convertSerializedDataToJson(
                'amasty_feed_entity',
                'entity_id',
                ['conditions_serialized']
            );
        }

        $setup->endSetup();
    }
}
